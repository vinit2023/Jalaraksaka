<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "jalraksha";

$conn = new mysqli($servername,$username,$password,$database);

if($conn->connect_error){
    die("Connection Failed".$conn->connect_error);
}
echo "connect sucessfully";
$name = $_POST["name"];
$email = $_POST["email"];

$sql = "INSERT INTO input(name,email) VALUES('$name','$email')";

$conn->query($sql);
$conn->close();
echo "Test";
?>
